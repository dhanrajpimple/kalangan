"""CLIP/text encoder model components."""
