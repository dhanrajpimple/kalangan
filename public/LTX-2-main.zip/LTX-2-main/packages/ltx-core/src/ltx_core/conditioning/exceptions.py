class ConditioningError(Exception):
    """
    Class for conditioning-related errors.
    """
